test = [[1,2], [3,4]]
test.